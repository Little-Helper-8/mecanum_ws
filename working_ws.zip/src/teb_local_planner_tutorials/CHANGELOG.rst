^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package teb_local_planner_tutorials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.4 (2019-07-03)
------------------
* Update of teb parameters
* comply with tf2: fixed error when using the launch files (thanks to doisyg).
* Contributors: Christoph Rösmann, doisyg

0.2.3 (2018-08-08)
------------------
* tf prefixes removed to comply with tf2
* Contributors: Christoph Rösmann

0.2.2 (2018-06-15)
------------------
* Example scripts, configurations and launch files for planning with dynamic obstacles added
* Scripts updated to consider the costmap_converter::ObstacleArrayMsg message
* Contributors: Christoph Rösmann, Franz Albers

0.2.1 (2016-11-15)
------------------
* Default parameters updated
* Navigation run-dependencies added

0.2.0 (2016-05-23)
------------------
* Added example setup for an omnidirectionl robot (ROS kinetic+)
* Run-dependency removed: metapackage navigation


0.0.2 (2016-04-18)
------------------
* This is a minor release due to the final releases for Saucy, Utopic and Vivid.
* Deprecated parameters are removed from the config in order to avoid warnings each time the planner is initialized.
* A costmap conversion example is now included.

0.0.1 (2016-04-14)
------------------
* Initial release with two stage simulation examples (diffdrive and carlike robots) and all tutorial scripts.

