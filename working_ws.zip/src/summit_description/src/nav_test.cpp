// #include "ros/ros.h"
// #include "std_msgs/String.h"
// #include <move_base_msgs/MoveBaseAction.h>
// #include "stdio.h"
// #include "math.h"

// using namespace std;

// int flagg=0;
// ros::Publisher chatter_pub;

// move_base_msgs::MoveBaseActionGoal waypoint1,waypoint2,waypoint;

// // waypoint1.header.stamp = ros::Time::now();
// // waypoint1.goal.target_pose.header.stamp = ros::Time::now();
// // waypoint1.goal.target_pose.header.frame_id = "map";
// // waypoint1.goal.target_pose.pose.position.x = -4;
// // waypoint1.goal.target_pose.pose.position.y = -1;
// // waypoint1.goal.target_pose.pose.position.z = 0;
// // waypoint1.goal.target_pose.pose.orientation.x = 0;
// // waypoint1.goal.target_pose.pose.orientation.y = 0;
// // waypoint1.goal.target_pose.pose.orientation.z = -0.4;
// // waypoint1.goal.target_pose.pose.orientation.w = 1;


// // waypoint2.header.stamp = ros::Time::now();
// // waypoint2.goal.target_pose.header.stamp = ros::Time::now();
// // waypoint2.goal.target_pose.header.frame_id = "map";
// // waypoint2.goal.target_pose.pose.position.x = -4;
// // waypoint2.goal.target_pose.pose.position.y = 1;
// // waypoint2.goal.target_pose.pose.position.z = 0;
// // waypoint2.goal.target_pose.pose.orientation.x = 0;
// // waypoint2.goal.target_pose.pose.orientation.y = 0;
// // waypoint2.goal.target_pose.pose.orientation.z = 0.4;
// // waypoint2.goal.target_pose.pose.orientation.w = 1;


// waypoint = waypoint1;
// void chatterCallback(const move_base_msgs::MoveBaseActionResult msg)
// {
// 	if(waypoint==waypoint1)
//   		waypoint = waypoint2;
//   	else
//   		waypoint = waypoint1;
//   	chatter_pub.publish(waypoint);
// }

// int main(int argc, char **argv)
// {
//   ros::init(argc, argv, "nav_test");
//   ros::NodeHandle n;
//   ros::Subscriber sub = n.subscribe("/move_base/result", 10, chatterCallback);
//   ros::Publisher chatter_pub = n.advertise<move_base_msgs::MoveBaseActionGoal>("move_base/goal", 10);

//   if(flagg==0)
//   {
//   	chatter_pub.publish(waypoint1);
//   	flagg=1;
//   }
  
//   ros::spin();
//   return 0;
// }


#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

int main(int argc, char** argv){
  ros::init(argc, argv, "simple_navigation_goals");

  //tell the action client that we want to spin a thread by default
  MoveBaseClient ac("move_base", true);

  //wait for the action server to come up
  while(!ac.waitForServer(ros::Duration(5.0))){
    ROS_INFO("Waiting for the move_base action server to come up");
  }

  move_base_msgs::MoveBaseGoal goal, waypoint1, waypoint2;

  waypoint1.target_pose.header.frame_id = "map";
  waypoint1.target_pose.header.stamp = ros::Time::now();

  waypoint1.target_pose.pose.position.x = -2.15;
  waypoint1.target_pose.pose.position.y = -3.38;
  waypoint1.target_pose.pose.orientation.w = 0.71;
  waypoint1.target_pose.pose.orientation.z = -0.70;

  waypoint2.target_pose.header.frame_id = "map";
  waypoint2.target_pose.header.stamp = ros::Time::now();

  waypoint2.target_pose.pose.position.x = 0.0;
  waypoint2.target_pose.pose.position.y = 0.0;
  waypoint2.target_pose.pose.orientation.w = 1.0;
  waypoint2.target_pose.pose.orientation.z = 0;

  //we'll send a goal to the robot to move 1 meter forward
  // goal.target_pose.header.frame_id = "map";
  // goal.target_pose.header.stamp = ros::Time::now();

  // goal.target_pose.pose.position.x = 1.0;
  // goal.target_pose.pose.orientation.w = 1.0;

  goal = waypoint1;
  int switch_c =1;

  ROS_INFO("Sending goal");
  while(ros::ok())
  {
  	ac.sendGoal(goal);

	ac.waitForResult();

	if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
	{
		ROS_INFO("Hooray, the base moved 1 meter forward");
		if(switch_c==1)
		{
	  		goal = waypoint2;
	  		switch_c=0;
	  		ros::Duration(30.0).sleep();
		}
	  	else
	  	{
	  		goal = waypoint1;
	  		switch_c=1;
	  		ros::Duration(30.0).sleep();
	  	}
	}
	else
	{
		ROS_INFO("The base failed to move forward 1 meter for some reason");
	}

  }
  
  return 0;
}