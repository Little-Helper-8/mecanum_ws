# RTIMULib-Arduino - a versatile 9-dof and 10-dof IMU library for the Arduino

## Please note that this project is no longer active and is of historical interest only.


