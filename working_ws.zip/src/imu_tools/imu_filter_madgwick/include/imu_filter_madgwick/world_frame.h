#ifndef IMU_FILTER_MADGWICK_WORLD_FRAME_H_
#define IMU_FILTER_MADGWICK_WORLD_FRAME_H_

namespace WorldFrame {
  enum WorldFrame { ENU, NED, NWU };
}

#endif
